# Node.js-Music-Player
It is a music player developed using node.js and SoundCloud API for running random music using the api
